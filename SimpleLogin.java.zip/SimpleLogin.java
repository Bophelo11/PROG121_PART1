import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;


//Setting up my actual password
public class SimpleLogin {
    public static void main(String[] args) {
        String correctUsername = "Chabo";
        String CorrectNumber = "0833449974";
        String correctPassword = "Bophelo#72";

        Scanner scanner = new Scanner(System.in);
// prompting user for correct password
        System.out.print("Enter Username: ");
        String usernameInput = scanner.nextLine();

//Prompting user for correct password

        System.out.print("Enter Password: ");
        String passwordInput = scanner.nextLine();

        //Prompting username for correct Cellnumber
        System.out.print("Enter Cellphone number");
        String CellPhoneInput = scanner.nextLine();


        if (usernameInput.equals(correctUsername) && passwordInput.equals(correctPassword) && CellPhoneInput.equals(CorrectNumber)) {
            System.out.println("Access Granted! Welcome.");
        } else {
            System.out.println("Invalid credentials. Access Denied.");
        }
    }
}


